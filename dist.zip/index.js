"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
// Import the PostsRoutes from the post.routes file
const routes_1 = __importDefault(require("./routes/routes"));
// Create an instance of the Express
exports.app = (0, express_1.default)();
// Define the port to listen on
const PORT = process.env.PORT || 3001;
console.log("PORT in env file is: " + process.env.PORT);
exports.app.use(express_1.default.json());
// Use the PostsRoutes for any routes starting with /posts
//app.use("/",routes);
exports.app.use('/', routes_1.default);
// Start the server
exports.app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
