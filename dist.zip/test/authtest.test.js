"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const chai_http_1 = __importDefault(require("chai-http"));
const chai_2 = __importDefault(require("chai"));
const mocha_1 = require("mocha");
const authMiddleware_1 = require("../controllers/authMiddleware");
const HttpStatusCode_1 = require("../controllers/HttpStatusCode");
const app_1 = __importDefault(require("../controllers/app"));
// Initialize Express application for testing
//const app: Express = express();
// Use the basicAuth middleware in the Express app
app_1.default.use(authMiddleware_1.basicAuth);
// Use Chai HTTP plugin
chai_2.default.use(chai_http_1.default);
(0, mocha_1.describe)('basicAuth Middleware Tests', () => {
    (0, mocha_1.it)('should allow access with correct credentials', (done) => {
        // Send a request with correct credentials
        chai_2.default.request(app_1.default)
            .get('/')
            .set('Authorization', 'Basic ' + Buffer.from('admin:password').toString('base64'))
            .end((err, res) => {
            (0, chai_1.expect)(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Ok);
            (0, chai_1.expect)(res.body).to.deep.equal({ message: 'Authorized' });
            done();
        });
    });
    (0, mocha_1.it)('should deny access with incorrect credentials', (done) => {
        // Send a request with incorrect credentials
        chai_2.default.request(app_1.default)
            .get('/')
            .set('Authorization', 'Basic ' + Buffer.from('user:wrongpassword').toString('base64'))
            .end((err, res) => {
            (0, chai_1.expect)(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Unauthorized);
            (0, chai_1.expect)(res.body).to.deep.equal({ message: 'Unauthorized - Invalid credentials' });
            done();
        });
    });
    (0, mocha_1.it)('should deny access with invalid username format', (done) => {
        // Send a request with invalid username format
        chai_2.default.request(app_1.default)
            .get('/')
            .set('Authorization', 'Basic ' + Buffer.from('user@123:password').toString('base64'))
            .end((err, res) => {
            (0, chai_1.expect)(res).to.have.status(HttpStatusCode_1.HttpStatusCode.BadRequest);
            (0, chai_1.expect)(res.body).to.deep.equal({ message: 'Invalid username format - Username must contain only alphanumeric characters' });
            done();
        });
    });
    (0, mocha_1.it)('should deny access without credentials', (done) => {
        // Send a request without Authorization header
        chai_2.default.request(app_1.default)
            .get('/')
            .end((err, res) => {
            (0, chai_1.expect)(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Unauthorized);
            (0, chai_1.expect)(res.body).to.deep.equal({ message: 'Unauthorized - Username and password are required' });
            done();
        });
    });
});
