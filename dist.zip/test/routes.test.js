"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
//import { expect } from 'chai';
const chai_http_1 = __importDefault(require("chai-http"));
const chai_1 = __importDefault(require("chai"));
const mocha_1 = require("mocha");
const HttpStatusCode_1 = require("../controllers/HttpStatusCode");
//import app from '../controllers/app';
const __1 = require("..");
const expect = chai_1.default.expect;
chai_1.default.use(chai_http_1.default);
(0, mocha_1.describe)('Routes with basicAuth Middleware Tests', () => {
    // Test case to verify access with correct credentials
    (0, mocha_1.it)('should allow access with correct credentials', (done) => {
        // Send a request with correct credentials
        chai_1.default.request(__1.app)
            .post('/insertrecord') // Protected route using basicAuth middleware
            .set('Authorization', 'Basic ' + Buffer.from('admin:password').toString('base64'))
            .send({
            "id": 999,
            "firstName": "Asish",
            "lastName": "K"
        })
            .end((err, res) => {
            expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Ok); // Expect HTTP status 200
            expect(res.body).to.deep.equal({ message: 'Record created successfully' }); // Expect response message
            done(); // Callback to signal completion of the test
        });
    });
    // Test case to verify rejection with incorrect credentials
    (0, mocha_1.it)('should reject access with incorrect credentials', (done) => {
        // Send a request with incorrect credentials
        chai_1.default.request(__1.app)
            .post('/insertrecord') // Protected route using basicAuth middleware
            .set('Authorization', 'Basic ' + Buffer.from('invaliduser:invalidpass').toString('base64'))
            .send({
            "id": 999,
            "firstName": "Asish",
            "lastName": "K"
        })
            .end((err, res) => {
            expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Unauthorized); // Expect HTTP status 401 (Unauthorized)
            expect(res.body).to.have.property('message').that.includes('Unauthorized - Invalid credentials'); // Expect error message
            done(); // Callback to signal completion of the test
        });
    });
});
//chai.use(chaiHttp);
// Test case for inserting a new record (POST /insertrecord)
(0, mocha_1.it)('Should insert a new record with correct credentials', (done) => {
    const requestBody = {
        "id": 999,
        "firstName": "Asish",
        "lastName": "K"
    };
    chai_1.default.request(__1.app)
        .post('/insertrecord')
        .set('Authorization', 'Basic ' + Buffer.from('admin:password').toString('base64'))
        .send(requestBody)
        .end((err, res) => {
        expect(res).to.be.json;
        expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Ok);
        expect(res.body).to.have.property('message').that.includes('Record created successfully');
        done();
    });
}).timeout(30000);
// Test case for unauthorized access (POST /insertrecord with invalid credentials)
(0, mocha_1.it)('Should return an error message for invalid credentials', (done) => {
    const requestBody = {
        "id": 999,
        "firstName": "Asish",
        "lastName": "K"
    };
    chai_1.default.request(__1.app)
        .post('/insertrecord')
        .set('Authorization', 'Basic ' + Buffer.from('invaliduser:invalidpass').toString('base64'))
        .send(requestBody)
        .end((err, res) => {
        expect(res).to.be.json;
        expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Unauthorized);
        expect(res.body).to.have.property('message').that.includes('Unauthorized - Invalid credentials');
        done();
    });
}).timeout(30000);
// Test case for getting a specific record (GET /getrecord/:empId)
(0, mocha_1.it)('Should return a specific record with correct credentials', (done) => {
    const empId = "999";
    chai_1.default.request(__1.app)
        .get(`/getrecord/${empId}`)
        .set('Authorization', 'Basic ' + Buffer.from('admin:password').toString('base64'))
        .end((err, res) => {
        console.log(res.body); // Log the response body to inspect its structure
        expect(res).to.be.json;
        expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Ok);
        //expect(res.body).to.have.property('id'); // Update this assertion based on the response structure
        done();
    });
}).timeout(10000);
// Test case for updating a record (PUT /updaterecord/:empId)
(0, mocha_1.it)('Should update a specific record with correct credentials', (done) => {
    const empId = "999";
    const updatedData = {
        "lastName": "UpdatedLastName"
    };
    chai_1.default.request(__1.app)
        .put(`/updaterecord/${empId}`)
        .set('Authorization', 'Basic ' + Buffer.from('admin:password').toString('base64'))
        .send(updatedData)
        .end((err, res) => {
        expect(res).to.be.json;
        expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Ok);
        expect(res.body).to.have.property('message').that.includes('Record updated successfully');
        done();
    });
}).timeout(10000);
// Test case for deleting a record (DELETE /deleterecord/:empId)
(0, mocha_1.it)('Should delete a specific record with correct credentials', (done) => {
    const empId = "999";
    chai_1.default.request(__1.app)
        .delete(`/deleterecord/${empId}`)
        .set('Authorization', 'Basic ' + Buffer.from('admin:password').toString('base64'))
        .end((err, res) => {
        expect(res).to.be.json;
        expect(res).to.have.status(HttpStatusCode_1.HttpStatusCode.Ok);
        expect(res.body).to.have.property('message').that.includes('Record deleted successfully');
        done();
    });
}).timeout(10000);
// it("Should insert a new record", (done) => {
//         const requestBody = {
//           "id": 999,
//           "firstName": "Asish",
//           "lastName": "K"
//         };
//         chai.request(app)
//           .post("/insertrecord")
//           .set('Authorization', 'Basic ' + Buffer.from('invaliduser:invalidpass').toString('base64'))
//           .send(requestBody) // Send the request body directly
//           .end((err, response) => {
//             // Assert the response
//             expect(response).to.be.json;
//             expect(response).to.have.status(HttpStatusCode.Ok); // Check for the expected status code
//             expect(response.body).to.have.property('message').that.includes('Record created successfully'); // Check for a success message in the response
//             if (err) return done(err);
//             done();
//           });
//       }).timeout(30000);      
//    it("Should return error message", (done) => {
//       const requestBody = {
//           "id" : 999,
//           "firstName": "Asish",
//           "lastName": "K"
//       };
//       chai.request(app)
//       .post("/insertrecord")
//       .send(requestBody)
//       .end((err, response) => {
//           expect(response)
//           .to.be.json;
//           expect(response)
//           .have.status(HttpStatusCode.BadRequest);
//           if (err) return done(err);
//           done();
//       })
//   }).timeout(30000);
//    it("Should return error message1", (done) => {
//        const testProduct = {
//            "firstName": "Asish",
//            "address" : "Odisha"
//        };
//        chai.request(app)
//        .post("/insertrecord")
//        .send(testProduct)
//        .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.Ok);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(30000);
//    it("Should return error message", (done) => {
//       const testProduct = {};
//       chai.request(app)
//       .post("/insertrecord")
//       .send(testProduct)
//       .end((err, response) => {
//           expect(response)
//           .to.be.json;
//           expect(response)
//           .have.status(HttpStatusCode.BadRequest);
//           if (err) return done(err);
//           done();
//       })
//   }).timeout(30000);
// describe("Get request to /getrecord/:empId", async () => {
//    it("Should return a array of one record", (done) => {
//        const empId = "999";
//        chai.request(app)
//        .get(`/getrecord/${empId}`)
//        .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.Ok);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
//    it("Should return error mesage", (done) => {
//       const empId = 9999;
//       chai.request(app)
//       .get(`/getrecord/${empId}`)
//       .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.NotFound);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
// });
// describe("PUT request to /updaterecord/:empId", async () => {
//    it("Should return a array of one produts", (done) => {
//        const empId = "999";
//        const recordToBeUpdated = {
//            "lastName": "Sahoo",
//        }
//        chai.request(app)
//        .put(`/updaterecord/${empId}`)
//        .send(recordToBeUpdated)
//        .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.Ok);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
//    it("Should return error mesage", (done) => {
//       const empId = 999;
//       const recordToBeUpdated = {
//           "address": "Odisha",
//       }
//       chai.request(app)
//       .put(`/updaterecord/${empId}`)
//       .send(recordToBeUpdated)
//       .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.Ok);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
// });
// describe("GET request to get all records", async () => {
//    it("Should return a array of records", (done) => {
//        chai.request(app)
//        .get("/getallrecords")
//        .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.Ok);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
// });
// describe("Delete request to /deleterecord/:empId", async () => {
//    it("Should return a array of one produts", (done) => {
//        const empId = "999";
//        chai.request(app)
//        .delete(`/deleterecord/${empId}`)
//        .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.Ok);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
//    it("Should return error mesage", (done) => {
//       const empId = 999;
//       chai.request(app)
//       .delete(`/deleterecord/${empId}`)
//       .end((err, response) => {
//            expect(response)
//            .to.be.json;
//            expect(response)
//            .have.status(HttpStatusCode.NotFound);
//            if (err) return done(err);
//            done();
//        })
//    }).timeout(10000);
// });
