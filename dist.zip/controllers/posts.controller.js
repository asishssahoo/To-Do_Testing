"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteAllRecords = exports.deleteRecordByEmpId = exports.updateRecordByEmpId = exports.getRecordByEmpId = exports.getAllRecords = exports.insertRecord = void 0;
const database_1 = require("../database");
const APIResponse_1 = require("./APIResponse");
const ErrorHandler_1 = require("./ErrorHandler");
const HttpStatusCode_1 = require("./HttpStatusCode");
function insertRecord(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const newRecord = req.body;
        const conn = yield (0, database_1.connect)();
        try {
            const result = yield conn.query('INSERT INTO todolist1 SET ?', newRecord);
            return res.json({
                message: "Record created successfully"
            });
        }
        catch (e) {
            const obj = JSON.parse(JSON.stringify(e));
            const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.BadRequest, new ErrorHandler_1.ErrorHandler(obj.sqlState, obj.sqlMessage).getSqlMessage());
            res.statusCode = errorResponse.statusCode;
            return res.json(errorResponse);
        }
    });
}
exports.insertRecord = insertRecord;
function getAllRecords(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const conn = yield (0, database_1.connect)();
        try {
            const [rows, _] = yield conn.query("SELECT * FROM todolist1");
            if (rows.length === 0) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.NotFound, "No records found");
                res.statusCode = errorResponse.statusCode;
                return res.json(errorResponse);
            }
            return res.status(HttpStatusCode_1.HttpStatusCode.Ok).json({
                statusCode: HttpStatusCode_1.HttpStatusCode.Ok,
                message: "Records fetched successfully",
                data: rows
            });
        }
        catch (e) {
            console.error("Error fetching records from database:", e);
            const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.InternalServerError, "Unable to fetch records");
            res.statusCode = errorResponse.statusCode;
            return res.json(errorResponse);
        }
    });
}
exports.getAllRecords = getAllRecords;
function getRecordByEmpId(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const id = req.params.empId;
        const conn = yield (0, database_1.connect)();
        try {
            const [rows, _] = yield conn.query("SELECT * FROM todolist1 WHERE id = ?", [id]);
            if (rows.length === 0) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.NotFound, `No record found for id = ${id}`);
                res.statusCode = errorResponse.statusCode;
                return res.json(errorResponse);
            }
            // Return the first record found (assuming there should be only one record with a given ID)
            return res.status(HttpStatusCode_1.HttpStatusCode.Ok).json({
                statusCode: HttpStatusCode_1.HttpStatusCode.Ok,
                message: "Record fetched successfully",
                data: rows[0] // Return the first record found
            });
        }
        catch (e) {
            console.error("Error fetching record from database:", e);
            const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.InternalServerError, "Unable to fetch record", e);
            res.statusCode = errorResponse.statusCode;
            return res.json(errorResponse);
        }
    });
}
exports.getRecordByEmpId = getRecordByEmpId;
function updateRecordByEmpId(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const id = req.params.empId;
        const updatePost = req.body;
        const conn = yield (0, database_1.connect)();
        try {
            // Fetch the existing record from the database
            const [existingRows] = yield conn.query("SELECT * FROM todolist1 WHERE id = ?", [id]);
            if (existingRows.length === 0) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.NotFound, `No record found for id = ${id}`);
                res.statusCode = errorResponse.statusCode;
                return res.json(errorResponse);
            }
            const existingRecord = existingRows[0];
            // Check if the update would result in any changes to the existing record
            const isIdenticalUpdate = compareRecords(existingRecord, updatePost);
            if (isIdenticalUpdate) {
                // No changes detected, consider this as a duplicate update
                return res.status(HttpStatusCode_1.HttpStatusCode.Ok).json({
                    message: "No changes detected, record is already up to date",
                    updatedId: id
                });
            }
            // Perform the update operation
            const [updateResult] = yield conn.query("UPDATE todolist1 SET ? WHERE id = ?", [updatePost, id]);
            const affectedRows = updateResult.affectedRows;
            if (affectedRows === 0) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.NotFound, `No record found for id = ${id}`);
                res.statusCode = errorResponse.statusCode;
                return res.json(errorResponse);
            }
            return res.status(HttpStatusCode_1.HttpStatusCode.Ok).json({
                message: "Record updated successfully",
                updatedId: id
            });
        }
        catch (e) {
            console.error("Error updating record in database:", e);
            // Use type assertion to ensure 'e' is treated as an Error
            const errorMessage = e.message || 'Unknown error';
            const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.InternalServerError, "Unable to update record", errorMessage);
            res.statusCode = errorResponse.statusCode;
            return res.json(errorResponse);
        }
    });
}
exports.updateRecordByEmpId = updateRecordByEmpId;
function compareRecords(record1, record2) {
    // Implement your custom logic to compare two records
    return JSON.stringify(record1) === JSON.stringify(record2);
}
function deleteRecordByEmpId(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        const id = req.params.empId;
        const conn = yield (0, database_1.connect)();
        try {
            const [deleteResult] = yield conn.query("DELETE FROM todolist1 WHERE id = ?", [id]);
            const affectedRows = deleteResult.affectedRows;
            if (affectedRows === 0) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.NotFound, `No record found for id = ${id}`);
                return res.status(HttpStatusCode_1.HttpStatusCode.NotFound).json(errorResponse);
            }
            return res.status(HttpStatusCode_1.HttpStatusCode.Ok).json({
                message: "Record deleted successfully",
                deletedId: id
            });
        }
        catch (e) {
            console.error("Error deleting record from database:", e);
            const errorMessage = (e instanceof Error) ? e.message : 'Unknown error';
            const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.InternalServerError, "Unable to delete record", errorMessage);
            return res.status(HttpStatusCode_1.HttpStatusCode.InternalServerError).json(errorResponse);
        }
    });
}
exports.deleteRecordByEmpId = deleteRecordByEmpId;
function deleteAllRecords(req, res) {
    return __awaiter(this, void 0, void 0, function* () {
        //const id = req.params.empId;
        const conn = yield (0, database_1.connect)();
        try {
            const posts = yield conn.query("DELETE FROM todolist1");
            const outputJson = JSON.parse(JSON.stringify(posts));
            const affectedRows = outputJson[0].affectedRows;
            if (affectedRows === 0) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.NotFound, "No record to be deleted");
                res.statusCode = errorResponse.statusCode;
                return res.json(errorResponse);
            }
            return res.json({
                message: "Records are deleted successfully.."
            });
        }
        catch (e) {
            if (e instanceof Error) {
                const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.InternalServerError, "Unable to delete records", e.message);
                res.statusCode = errorResponse.statusCode;
                return res.json(errorResponse);
            }
            const errorResponse = new APIResponse_1.ApiResponse(HttpStatusCode_1.HttpStatusCode.InternalServerError, "Unable to delete records", e);
            res.statusCode = errorResponse.statusCode;
            return res.json(errorResponse);
        }
    });
}
exports.deleteAllRecords = deleteAllRecords;
