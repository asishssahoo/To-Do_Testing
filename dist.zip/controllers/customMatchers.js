"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toBeTruthy = void 0;
const chai_1 = require("chai");
function toBeTruthy(value) {
    return (0, chai_1.expect)(value).equal(true);
}
exports.toBeTruthy = toBeTruthy;
