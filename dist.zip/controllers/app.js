"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const authMiddleware_1 = require("./authMiddleware");
const app = (0, express_1.default)();
// Define a route that uses the basicAuth middleware
app.get('/', authMiddleware_1.basicAuth, (req, res) => {
    res.status(200).json({ message: 'Authorized' });
});
exports.default = app;
