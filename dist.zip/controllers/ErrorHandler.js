"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorHandler = void 0;
class ErrorHandler {
    constructor(sqlState, sqlMessage) {
        this.sqlState = sqlState;
        this.sqlMessage = sqlMessage;
    }
    getSqlMessage() {
        if (this.sqlState == 23000) {
            return "Duplicate entry found..";
        }
        return this.sqlMessage;
    }
}
exports.ErrorHandler = ErrorHandler;
